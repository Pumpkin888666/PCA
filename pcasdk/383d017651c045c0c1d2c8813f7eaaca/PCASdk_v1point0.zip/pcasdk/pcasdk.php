<?php
/**
 * PCA SDK v1.0
 * @author Pumpkin aswdfgyhj@163.com
 * 2024-1-20
 */
define('ROOTS', dirname(__FILE__) . '/');
define('ROOT', dirname(ROOTS) . '/');
include ROOT.'./pcasdk/pclzip.lib.php';
class PCASdk
{
    public $PCASDK_VERSION = 'v1.0';
    private $app_id;
    private $app_key;
    private $authkey;
    private $app_author;
    private $app_version;
    private $version_id;
    private $PCA_CloudUrl = 'https://api.pumpkin8.cn/';
    public $database_file;
    public $bigTry = 3;
    public function __construct($arr)
    {
        $this->app_id = $arr['app_id'];
        $this->app_key = $arr['app_key'];
        $this->authkey = $arr['authkey'];
        $this->app_author = $arr['app_author'];
        $this->app_version = $arr['app_version'];
        $this->version_id = file_get_contents(ROOT.'./pcasdk/version_id');
        $this->auth();
    }
    public function auth()
    {
        $data = array('act' => 'auth');
        $reslut = $this->send_post($this->PCA_CloudUrl . 'api.php', $data);
        if ($reslut['code'] == 100) {
            echo 'PCASdk:授权激活失败！请联系PCA管理员。';
            exit;
        } else if ($reslut['code'] == 101) {
            echo 'PCASdk:授权过期！';
            exit;
        } else if ($reslut['code'] == -1) {
            echo 'PCASdk:服务器错误！';
            exit;
        } else if ($reslut['code'] == 102) {
            echo 'PCASdk:授权被封禁！';
            exit;
        } else if ($reslut['code'] == 103) {
            echo 'PCASdk:版本错误！';
            exit;
        } else if ($reslut['code'] == 104) {
            echo 'PCASdk:版本禁用！请更新软件！';
            exit;
        } else if ($reslut['code'] == 105) {
            echo 'PCASdk:软件关闭！';
            exit;
        } else if ($reslut['code'] == 106) {
            echo 'PCASdk:授权失败！';
            exit;
        } else if ($reslut['code'] == 107) {
            echo 'PCASdk:激活码未激活请使用<a href="">PCAInstaller</a>工具激活并下载最新的代码。';
            exit;
        } else if ($reslut['code'] == 108) {
            echo 'PCASdk:非法激活。';
            exit;
        } else if ($reslut['code'] == 109) {
            echo 'PCASdk:签名错误';
            exit;
        } else if ($reslut['code'] != 0) {
            echo 'PCASdk:通讯错误。';
            exit;
        }
    }
    private function send_post($url, $post_data, $try = 0)
    {
        // 发送POST请求 自动验证签名 自动加密信息
        $post_data['authkey'] = $this->super_aes256($this->authkey, 'encrypt');
        $post_data['app_version'] = $this->app_version ;
        $post_data['version_id'] = $this->version_id;
        $post_data['PCASDK_VERSION'] = $this->PCASDK_VERSION;
        $post_data['sign'] = $this->super_sign($this->app_id
            . $this->app_key
            . $this->authkey
            . $this->app_author
            . $this->app_version
            . $this->version_id
            . $this->PCASDK_VERSION);

        $postdata = http_build_query($post_data);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $result = $this->super_aes256($result, 'decrypt');
        if (empty($result)) {
            if ($try >= $this->bigTry) {
                echo 'PCASdk：通讯错误000 【已达PCASdk最大重发次数！当前重发：' . $try . '】';
                exit;
            }
            return $this->send_post($url, $post_data, ($try + 1));
        }
        $result = json_decode($result, true);
        if (!$this->super_sign($result, $result['sign'])) {
            echo 'PCASdk:云端通讯签名错误';
            exit;
        }
        if ($result['code'] == 999) {
            echo 'PCASdk:该作者关闭了API接口开关。';
            exit;
        }

        return $result;
    }
    private function super_aes256($str, $model)
    {
        // 加密2 超级AES256加密 加密密文仅当秒可解
        if ($model == "encrypt") {
            $key = 0;
            for ($i = 0; $i < 16; $i++) {
                $key .= md5($key . time());
            }
            for ($i = 0; $i < 8; $i++) {
                $str = openssl_encrypt($str, 'AES-256-CBC', $key, 0, 'I very like you.');
            }
            return $str;
        } else if ($model == 'decrypt') {
            $key = 0;
            for ($i = 0; $i < 16; $i++) {
                $key .= md5($key . time() . $this->authkey . $this->app_id . $this->app_key . $this->app_version . $this->app_author . $this->PCASDK_VERSION);
            }
            for ($i = 0; $i < 8; $i++) {
                $str = openssl_decrypt($str, 'AES-256-CBC', $key, 0, 'I very like you.');
            }
            return $str;
        }
    }
    private function super_sign($str, $check = null)
    {
        // 加密1 超级MD5签名
        if (!empty($check)) {
            $str = $str['code'] . $str['msg'] . $str['data'] . $str['time'];
        }
        for ($i = 0; $i < 10; $i++) {
            $str .= md5($str);
        }
        $strlen = strlen($str);
        for ($i = 0; $i < $strlen; $i++) {
            $str .= md5($str);
        }
        $str = md5($str);
        if (!empty($check)) {
            if ($str === $check) {
                return true;
            } else {
                return false;
            }
        }
        return $str;
    }
    public function getRole()
    {
        $data = array('act' => 'getRole');
        $reslut = $this->send_post($this->PCA_CloudUrl . 'api.php', $data);
        return $reslut['data']['role'];
    }
    public function getNotice()
    {
        $data = array('act' => 'getNotice');
        $reslut = $this->send_post($this->PCA_CloudUrl . 'api.php', $data);
        return $reslut['data']['notice'];
    }
    public function getEndTime()
    {
        $data = array('act' => 'getEndTime');
        $reslut = $this->send_post($this->PCA_CloudUrl . 'api.php', $data);
        return $reslut['data']['endtime'];
    }
    public function getUpdate()
    {
        $data = array('act' => 'getUpdate');
        $reslut = $this->send_post($this->PCA_CloudUrl . 'api.php', $data);
        return $reslut['data'];
    }
    public function update()
    {
        // 获取下载文件授权
        $data = array('act' => 'getUpdatePack');
        $reslut = $this->send_post($this->PCA_CloudUrl . 'api.php', $data);
        if ($reslut['code'] == 200) {
            return false;
        }
        $new_version_id = $reslut['data']['new_version_id'];
        $data = array(
            'url' => $reslut['data']['url'],
            'url1' => $reslut['data']['url1'],
            'file_type' => 'update_file'
        );

        // 下载更新包
        $updateFile = send_post($this->PCA_CloudUrl . 'filedownload.php', $data);
        if (!is_dir(ROOT.'./pcaupdate')) {
            mkdir(ROOT.'./pcaupdate', 0777);
        }
        file_put_contents(ROOT.'./pcaupdate/versionupdate.zip', $updateFile);

        // 解压
        $zip = new PclZip(ROOT.'./pcaupdate/versionupdate.zip');
        if (!$zip->extract(ROOT.'./pcaupdate/')) {
            echo '更新包解压失败！';
            exit;
        }

        // 检查更新包合规性
        $isok = false;
        if (file_exists(ROOT.'./pcaupdate/update.zip')) {
            $isok = true;
        }
        if (file_exists(ROOT.'./pcaupdate/update.sql')) {
            $isok = true;
        }
        if (!$isok) {
            echo '更新包不合规！';
            exit;
        }

        // 更新

        // 目录
        if (file_exists(ROOT.'./pcaupdate/update.zip')) {
            $updateZip = new PclZip(ROOT.'./pcaupdate/update.zip');

            $filelist = $updateZip->listContent();
            foreach ($filelist as $file) {
                if (file_exists(ROOT.'./' . $file['stored_filename'])) {
                    unlink(ROOT.'./' . $file['stored_filename']);
                }
            }

            if (!$updateZip->extract()) {
                echo '网站目录更新包解压失败！';
                exit;
            }
        }
        // 数据库
        if (file_exists(ROOT.'./pcaupdate/update.sql')) {
            require_once $this->database_file;

            $sqlss = file_get_contents(ROOT.'./pcaupdate/update.sql');
            $sqls = explode(';', $sqlss);
            $ok = 0;
            $fail = 0;
            $error = '';
            $DB->query('set names utf8');
            $DB->query("set sql_mode = ''");
            $pdo->setAttribute(PDO::ATTR_AUTOCOMMIT, 0);
            $pdo->beginTransaction();
            foreach ($sqls as $sql) {
                $sql = trim($sql);
                if ($sql == '') {
                    continue;
                }
                if ($DB->query($sql)) {
                    $ok++;
                } else {
                    $fail++;
                    $error .= '执行语句失败：' . $sql . '<br>';
                }
            }

            $pdo->setAttribute(PDO::ATTR_AUTOCOMMIT, 1);
            if ($fail) {
                $pdo->rollBack();
                return [$ok, $fail, $error];
            }
            $pdo->commit();
        }

        deleteDirectory(ROOT.'./pcaupdate');

        // 自更config配置 更新授权唯一版本标识
        unlink(ROOT.'./pcasdk/version_id');
        file_put_contents(ROOT.'./pcasdk/version_id', $new_version_id);

        return true;
    }
    public function getVar($name)
    {
        $data = array('act' => 'getRemote-variable', 'name' => $name);
        $reslut = $this->send_post($this->PCA_CloudUrl . 'api.php', $data);
        if ($reslut['code'] == -1) {
            return;
        }
        return $reslut['data']['content'];
    }
    public function request_forwarding($out_link, $pd = null)
    {
        $data = array('act' => 'request_forwarding', 'out_link' => $out_link, 'post_data' => $pd);
        $reslut = $this->send_post($this->PCA_CloudUrl . 'api.php', $data);
        return $reslut['data']['data'];
    }
}

function deleteDirectory($dir)
{
    // 删除文件夹 https://blog.csdn.net/Klaus_S/article/details/131439581
    if (!is_dir($dir)) {
        return false;
    }
    $files = array_diff(scandir($dir), array('.', '..'));
    foreach ($files as $file) {
        (is_dir("$dir/$file")) ? deleteDirectory("$dir/$file") : unlink("$dir/$file");
    }
    return rmdir($dir);
}

function send_post($url, $post_data)
{
    // 发送POST请求 普通
    $postdata = http_build_query($post_data);
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded',
            'content' => $postdata,
            'timeout' => 15 * 60 // 超时时间（单位:s）
        )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return $result;
}

?>