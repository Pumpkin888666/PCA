<?php
/**
 * @author Pumpkin aswdfgyhj@163.com
 * 2024-6-8
 */


$act = $_POST['act'];
$auth_code = $_POST['auth_code'];

switch ($act){
    case 'auth':
        $data = array('act' => 'auth', 'auth_code' => $auth_code);
        $r = send_post('https://api.pumpkin8.cn/installapi.php',$data);
        header("Content-Type:application/json; charset=utf-8");
        echo $r;
        break;
    case 'i1':
        // 激活授权码
        $data = array('act' => 'activation','auth_code' => $auth_code);
        $r = send_post('https://api.pumpkin8.cn/installapi.php', $data);
        $v = json_decode($r, true);

        // 放置版本ID
        if(!file_exists('./pcasdk')){
            mkdir('./pcasdk');
        }
        file_put_contents('./pcasdk/version_id', $v['data']['version_id']);

        header("Content-Type:application/json; charset=utf-8");
        echo $r;
        break;
    case 'i2':
        // 下载安装包

        // 获取授权
        $data = array('act' => 'getInstallPack', 'auth_code' => $auth_code);
        $r = send_post('https://api.pumpkin8.cn/installapi.php', $data);
        $r = json_decode($r,true);

        // 下载安装包至根目录
        $data = array(
            'url' => $r['data']['url'],
            'url1' => $r['data']['url1'],
            'file_type' => 'install_pack'
        );
        if(file_exists('./install_pack.zip')){
            unlink('./install_pack.zip');
        }
        $installFile = send_post('https://api.pumpkin8.cn/filedownload.php', $data);
        file_put_contents('./install_pack.zip', $installFile);

        json(0, '安装包下载成功');

        break;
    case 'i3':
        // 解压安装包

        require './8d948283f5d4a32469e7e2da29e31d41.php';
        $installZip = new PclZip('./install_pack.zip');


        $filelist = $installZip->listContent();
        foreach ($filelist as $file) {
            if (file_exists('./' . $file['stored_filename'])) {
                unlink('./' . $file['stored_filename']);
            }
        }

        if (!$installZip->extract('./')) {
            json(0, '文件解压失败');
        }

        json(0, '文件解压成功');

        break;
    case 'i4':
        // 删除PCAInstaller
        deleteDirectory('./6c80396d156f145c3592e05a5e019d5d');
        unlink('./2705a83a5a0659cce34583972637eda5.php');
        unlink('./8d948283f5d4a32469e7e2da29e31d41.php');
        json(0, 'PCAInstaller删除成功');
        break;
    default:
        json(404, '请求参数错误');
        break;
}

function json($code, $msg = null, $data = null)
{
    header("Content-Type:application/json; charset=utf-8");
    echo json_encode(array("code" => $code, "msg" => $msg, "data" => $data));
    exit;
}

function send_post($url, $post_data)
{
    // 发送POST请求 普通
    $postdata = http_build_query($post_data);
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded',
            'content' => $postdata,
            'timeout' => 15 * 60 // 超时时间（单位:s）
        )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return $result;
}


function deleteDirectory($dir)
{
    // 删除文件夹 https://blog.csdn.net/Klaus_S/article/details/131439581
    if (!is_dir($dir)) {
        return false;
    }
    $files = array_diff(scandir($dir), array('.', '..'));
    foreach ($files as $file) {
        (is_dir("$dir/$file")) ? deleteDirectory("$dir/$file") : unlink("$dir/$file");
    }
    return rmdir($dir);
}

?>